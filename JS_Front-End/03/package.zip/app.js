    const baseUrl = "http://localhost:3030/jsonstore/games/";
    const loadGamesBtn = document.getElementById("load-games");
    const addGameBtn = document.getElementById("add-game");
    const editGameBtn = document.getElementById("edit-game");
    const gamesList = document.getElementById("games-list");
    const form = document.querySelector("#form form");
  
    
    loadGamesBtn.addEventListener("click", function () {
      fetch(baseUrl)
        .then((response) => response.json())
        .then((data) => {
          gamesList.innerHTML = ""; 
          Object.values(data).forEach((game) => {
            const gameDiv = createGameDiv(game);
            gamesList.appendChild(gameDiv);
          });
          editGameBtn.disabled = true; 
        });
    });
  
    addGameBtn.addEventListener("click", function () {
      const gameData = {
        name: form["g-name"].value,
        type: form["type"].value,
        players: form["players"].value,
      };
  
      fetch(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(gameData),
      })
        .then((response) => response.json())
        .then(() => {
          loadGamesBtn.click();
          form.reset();
        });
    });
  
    function handleEditClick(event) {
      const gameDiv = event.target.closest(".board-game");
      const name = gameDiv.querySelector(".content p:nth-child(1)").textContent;
      const type = gameDiv.querySelector(".content p:nth-child(2)").textContent;
      const players = gameDiv.querySelector(".content p:nth-child(3)").textContent;
  
      form["g-name"].value = name;
      form["type"].value = type;
      form["players"].value = players;
  
      addGameBtn.disabled = true;
      editGameBtn.disabled = false;
      editGameBtn.addEventListener("click", function () {
        const gameData = {
          name: form["g-name"].value,
          type: form["type"].value,
          players: form["players"].value,
        };
        const gameId = gameDiv.dataset.id;
  
        fetch(baseUrl + gameId, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(gameData),
        })
          .then(() => {
            loadGamesBtn.click(); 
            form.reset(); 
            addGameBtn.disabled = false;
            editGameBtn.disabled = true;
          });
      });
    }
  
    function handleDeleteClick(event) {
        const gameDiv = event.target.parentElement.parentElement;
        const gameId = gameDiv.getAttribute("data-id");
      
        fetch(baseUrl + gameId, {
          method: "DELETE",
        })
        .then(() => gameDiv.remove())
      }
      
  
    function createGameDiv(game) {
      const gameDiv = document.createElement("div");
      gameDiv.classList.add("board-game");
      gameDiv.dataset.id = game._id;
  
      const contentDiv = document.createElement("div");
      contentDiv.classList.add("content");
      const nameP = document.createElement("p");
      nameP.textContent = game.name;
      const typeP = document.createElement("p");
      typeP.textContent = game.type;
      const playersP = document.createElement("p");
      playersP.textContent = game.players;
      contentDiv.appendChild(nameP);
      contentDiv.appendChild(typeP);
      contentDiv.appendChild(playersP);
  
      const buttonsDiv = document.createElement("div");
      buttonsDiv.classList.add("buttons-container");
      const changeBtn = document.createElement("button");
      changeBtn.classList.add("change-btn");
      changeBtn.textContent = "Change";
      const deleteBtn = document.createElement("button");
      deleteBtn.classList.add("delete-btn");
      deleteBtn.textContent = "Delete";
      buttonsDiv.appendChild(changeBtn);
      buttonsDiv.appendChild(deleteBtn);
  
      gameDiv.appendChild(contentDiv);
      gameDiv.appendChild(buttonsDiv);
  
      changeBtn.addEventListener("click", handleEditClick);
      deleteBtn.addEventListener("click", handleDeleteClick);
  
      return gameDiv;
    }
